package com.song.backfol.global.exception;

public class BoardException extends RuntimeException{
    public BoardException(String message) {
        super(message);
    }
}
